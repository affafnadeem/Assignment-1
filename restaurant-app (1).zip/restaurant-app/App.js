import React, { useState, createContext, useContext, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, StatusBar, SafeAreaView, FlatList, Image, Modal,
  Alert, Share
} from 'react-native';
import QRCode from 'react-native-qrcode-svg';

// ========== MOCK DATA ==========
// Using a single combined Arabic food image for all menu items
const MENU_ITEMS = [
  // MANDI
  { id: 1, name: 'Royal Mandi', arabicName: 'المندي الملكي', price: 89, category: 'Mandi', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Whole chicken with saffron rice, nuts, and raisins', available: true, isSpecial: true },
  { id: 2, name: 'Chicken Mandi', arabicName: 'مندي دجاج', price: 65, category: 'Mandi', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Tender chicken with basmati rice', available: true, isSpecial: false },
  { id: 3, name: 'Lamb Mandi', arabicName: 'مندي لحم', price: 89, category: 'Mandi', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Slow-cooked lamb with aromatic rice', available: true, isSpecial: true },
  
  // KABSA
  { id: 4, name: 'Chicken Kabsa', arabicName: 'كابسة دجاج', price: 59, category: 'Kabsa', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Spiced rice with chicken and vegetables', available: true, isSpecial: false },
  { id: 5, name: 'Lamb Kabsa', arabicName: 'كابسة لحم', price: 79, category: 'Kabsa', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Tender lamb with fragrant rice', available: true, isSpecial: false },
  
  // STARTERS
  { id: 6, name: 'Hummus', arabicName: 'حمص', price: 28, category: 'Starters', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Creamy chickpea dip with olive oil', available: true, isSpecial: false },
  { id: 7, name: 'Mutabbal', arabicName: 'متبل', price: 32, category: 'Starters', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Smoky eggplant dip with tahini', available: true, isSpecial: false },
  { id: 8, name: 'Falafel', arabicName: 'فلافل', price: 24, category: 'Starters', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Crispy chickpea patties with tahini sauce', available: true, isSpecial: false },
  { id: 9, name: 'Warak Enab', arabicName: 'ورق عنب', price: 32, category: 'Starters', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Stuffed grape leaves with rice', available: true, isSpecial: false },
  
  // MAIN
  { id: 10, name: 'Shawarma Chicken', arabicName: 'شاورما دجاج', price: 32, category: 'Main', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Grilled chicken wrapped in pita bread', available: true, isSpecial: false },
  { id: 11, name: 'Mansaf', arabicName: 'منسف', price: 95, category: 'Main', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Lamb with fermented yogurt rice', available: true, isSpecial: true },
  { id: 12, name: 'Maqluba', arabicName: 'مقلوبة', price: 75, category: 'Main', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Upside-down rice with chicken', available: true, isSpecial: false },
  
  // SALADS
  { id: 13, name: 'Fattoush', arabicName: 'فتوش', price: 22, category: 'Salads', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Fresh vegetable salad with crispy bread', available: true, isSpecial: false },
  { id: 14, name: 'Tabouleh', arabicName: 'تبولة', price: 24, category: 'Salads', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Parsley, bulgur, tomato, mint salad', available: true, isSpecial: false },
  
  // DESSERTS
  { id: 15, name: 'Kunafa', arabicName: 'كنافة', price: 42, category: 'Desserts', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Sweet cheese pastry with syrup', available: true, isSpecial: true },
  { id: 16, name: 'Umm Ali', arabicName: 'أم علي', price: 35, category: 'Desserts', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Bread pudding with nuts and raisins', available: true, isSpecial: false },
  
  // DRINKS
  { id: 17, name: 'Mint Lemonade', arabicName: 'ليمون بالنعناع', price: 18, category: 'Drinks', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Fresh mint lemonade', available: true, isSpecial: false },
  { id: 18, name: 'Arabic Coffee', arabicName: 'قهوة عربية', price: 15, category: 'Drinks', 
    image: 'https://i.imgur.com/placeholder.jpg', 
    description: 'Cardamom coffee with dates', available: true, isSpecial: false },
];

const COMBINED_MENU_IMAGE = 'https://images.pexels.com/photos/1279330/pexels-photo-1279330.jpeg?auto=compress&cs=tinysrgb&w=600';

const DEFAULT_USERS = [
  { id: 1, name: 'Hamid Saleem', email: 'manager@restaurant.ae', password: 'manager123', phone: '+971501234567', role: 'manager' },
  { id: 2, name: 'Salahuddin', email: 'salah@email.com', password: 'salah123', phone: '+971551234567', role: 'customer' },
  { id: 3, name: 'umme Waleed', email: 'wali@email.com', password: 'wali123', phone: '+971561234567', role: 'customer' },
];

// ========== CONTEXT ==========
const AppContext = createContext();

const App = () => {
  const [users, setUsers] = useState(DEFAULT_USERS);
  const [currentUser, setCurrentUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [menuItems, setMenuItems] = useState(MENU_ITEMS);
  const [tables, setTables] = useState([
    { id: 'T1', number: 1, capacity: 2, status: 'available' },
    { id: 'T2', number: 2, capacity: 2, status: 'available' },
    { id: 'T3', number: 3, capacity: 4, status: 'available' },
    { id: 'T4', number: 4, capacity: 4, status: 'booked' },
    { id: 'T5', number: 5, capacity: 6, status: 'available' },
    { id: 'T6', number: 6, capacity: 6, status: 'available' },
  ]);

  const addToCart = (item) => {
    const existing = cart.find(c => c.id === item.id);
    if (existing) {
      setCart(cart.map(c => c.id === item.id ? { ...c, quantity: c.quantity + 1 } : c));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const updateCartQuantity = (id, change) => {
    setCart(cart.map(item => 
      item.id === id ? { ...item, quantity: Math.max(1, item.quantity + change) } : item
    ));
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const placeOrder = (orderDetails) => {
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryFee = orderDetails.orderType === 'Delivery' ? 15 : 0;
    const tax = subtotal * 0.05;
    
    const newOrder = {
      id: `ORD-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      items: [...cart],
      subtotal,
      deliveryFee,
      tax,
      total: subtotal + deliveryFee + tax,
      date: new Date().toISOString(),
      status: 'Pending',
      ...orderDetails
    };
    
    setOrders([newOrder, ...orders]);
    setCart([]);
    Alert.alert('Success', `Order placed! Payment: ${orderDetails.paymentMethod}`);
  };

  const makeReservation = (details) => {
    setTables(tables.map(table => 
      table.number === details.tableNumber ? { ...table, status: 'booked' } : table
    ));
    
    const newReservation = {
      id: `RES-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      qrCode: `https://restaurant.app/reservation/${Date.now()}`,
      status: 'Confirmed',
      createdAt: new Date().toISOString(),
      ...details
    };
    setReservations([newReservation, ...reservations]);
    Alert.alert('Success', `Table ${details.tableNumber} reserved successfully!`);
  };

  const updateOrderStatus = (orderId, newStatus) => {
    setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
  };

  const updateMenuItem = (itemId, updatedData) => {
    setMenuItems(menuItems.map(item => 
      item.id === itemId ? { ...item, ...updatedData } : item
    ));
  };

  const addMenuItem = (newItem) => {
    const newId = Math.max(...menuItems.map(i => i.id), 0) + 1;
    setMenuItems([...menuItems, { ...newItem, id: newId }]);
  };

  const deleteMenuItem = (itemId) => {
    setMenuItems(menuItems.filter(item => item.id !== itemId));
  };

  const register = (userData) => {
    const existingUser = users.find(u => u.email === userData.email);
    if (existingUser) {
      Alert.alert('Error', 'Email already registered');
      return false;
    }
    const newUser = { id: users.length + 1, ...userData, role: 'customer' };
    setUsers([...users, newUser]);
    setCurrentUser(newUser);
    return true;
  };

  const login = (email, password, role) => {
    const user = users.find(u => u.email === email && u.password === password && u.role === role);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    Alert.alert('Error', 'Invalid credentials');
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    setCart([]);
  };

  const value = {
    currentUser,
    cart,
    orders,
    reservations,
    menuItems,
    tables,
    addToCart,
    updateCartQuantity,
    removeFromCart,
    placeOrder,
    makeReservation,
    updateOrderStatus,
    updateMenuItem,
    addMenuItem,
    deleteMenuItem,
    register,
    login,
    logout,
  };

  return (
    <AppContext.Provider value={value}>
      <StatusBar barStyle="light-content" backgroundColor="#0A0A0A" />
      {!currentUser ? <AuthScreen /> : currentUser.role === 'manager' ? <ManagerDashboard /> : <CustomerApp />}
    </AppContext.Provider>
  );
};

// ========== AUTH SCREEN ==========
const AuthScreen = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState('customer');
  const [showPassword, setShowPassword] = useState(false);
  const { login, register } = useContext(AppContext);

  const handleSubmit = () => {
    if (isLogin) {
      login(email, password, role);
    } else {
      if (!name || !email || !phone || !password) {
        Alert.alert('Error', 'Please fill all fields');
        return;
      }
      register({ name, email, phone, password });
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.authContainer}>
        <View style={styles.logoSection}>
          <View style={styles.logoCircle}>
            <Text style={styles.logoEmoji}>🍽️</Text>
          </View>
          <Text style={styles.restaurantArabic}>بيت الزعفران</Text>
          <Text style={styles.restaurantEnglish}>SAFFRON HOUSE</Text>
          <Text style={styles.tagline}>Authentic Arabian Cuisine</Text>
        </View>

        <View style={styles.authCard}>
          <View style={styles.authToggle}>
            <TouchableOpacity 
              style={[styles.toggleButton, isLogin && styles.toggleActive]} 
              onPress={() => setIsLogin(true)}>
              <Text style={[styles.toggleText, isLogin && styles.toggleTextActive]}>Login</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.toggleButton, !isLogin && styles.toggleActive]} 
              onPress={() => setIsLogin(false)}>
              <Text style={[styles.toggleText, !isLogin && styles.toggleTextActive]}>Register</Text>
            </TouchableOpacity>
          </View>

          {!isLogin && (
            <>
              <TextInput 
                style={styles.authInput} 
                placeholder="Full Name" 
                placeholderTextColor="#666"
                value={name} 
                onChangeText={setName} 
              />
              <TextInput 
                style={styles.authInput} 
                placeholder="Phone Number" 
                placeholderTextColor="#666"
                value={phone} 
                onChangeText={setPhone} 
                keyboardType="phone-pad" 
              />
            </>
          )}

          <TextInput 
            style={styles.authInput} 
            placeholder="Email" 
            placeholderTextColor="#666"
            value={email} 
            onChangeText={setEmail} 
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <View style={styles.passwordWrapper}>
            <TextInput 
              style={[styles.authInput, { flex: 1, marginBottom: 0 }]} 
              placeholder="Password" 
              placeholderTextColor="#666"
              value={password} 
              onChangeText={setPassword} 
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
              <Text style={styles.showHide}>{showPassword ? 'Hide' : 'Show'}</Text>
            </TouchableOpacity>
          </View>

          {isLogin && (
            <View style={styles.roleSelect}>
              <TouchableOpacity 
                style={[styles.roleOption, role === 'customer' && styles.roleActive]} 
                onPress={() => setRole('customer')}>
                <Text style={[styles.roleText, role === 'customer' && styles.roleTextActive]}>Customer</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.roleOption, role === 'manager' && styles.roleActive]} 
                onPress={() => setRole('manager')}>
                <Text style={[styles.roleText, role === 'manager' && styles.roleTextActive]}>Manager</Text>
              </TouchableOpacity>
            </View>
          )}

          <TouchableOpacity style={styles.authButton} onPress={handleSubmit}>
            <Text style={styles.authButtonText}>{isLogin ? 'LOGIN' : 'REGISTER'}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

// ========== CUSTOMER APP ==========
const CustomerApp = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const { currentUser, cart, orders, menuItems, addToCart, logout } = useContext(AppContext);

  const categories = ['All', 'Mandi', 'Kabsa', 'Starters', 'Main', 'Salads', 'Desserts', 'Drinks'];
  
  const filteredItems = menuItems.filter(item => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.arabicName.includes(searchQuery);
    return matchesCategory && matchesSearch;
  });

  const specials = menuItems.filter(item => item.isSpecial);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.customerHeader}>
        <View>
          <Text style={styles.greeting}>Welcome back,</Text>
          <Text style={styles.userName}>{currentUser?.name}</Text>
        </View>
        <TouchableOpacity onPress={logout}>
          <Text style={styles.logoutBtn}>Logout</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        {activeTab === 'home' && <HomeTab specials={specials} setActiveTab={setActiveTab} />}
        {activeTab === 'menu' && (
          <MenuTab 
            categories={categories}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            filteredItems={filteredItems}
            addToCart={addToCart}
          />
        )}
        {activeTab === 'cart' && <CartTab />}
        {activeTab === 'orders' && <OrdersTab orders={orders.filter(o => o.userId === currentUser?.id)} />}
        {activeTab === 'reservations' && <ReservationScreen />}
        {activeTab === 'profile' && <ProfileTab currentUser={currentUser} />}
      </View>

      <View style={styles.bottomNav}>
        {[
          { key: 'home', icon: '🏠', label: 'Home' },
          { key: 'menu', icon: '📋', label: 'Menu' },
          { key: 'cart', icon: '🛒', label: 'Cart', badge: cart.length },
          { key: 'reservations', icon: '📅', label: 'Reserve' },
          { key: 'orders', icon: '📦', label: 'Orders' },
          { key: 'profile', icon: '👤', label: 'Profile' },
        ].map(tab => (
          <TouchableOpacity key={tab.key} style={styles.navItem} onPress={() => setActiveTab(tab.key)}>
            <Text style={[styles.navIcon, activeTab === tab.key && styles.navIconActive]}>{tab.icon}</Text>
            <Text style={[styles.navLabel, activeTab === tab.key && styles.navLabelActive]}>{tab.label}</Text>
            {tab.badge > 0 && <View style={styles.navBadge}><Text style={styles.navBadgeText}>{tab.badge}</Text></View>}
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
};

const HomeTab = ({ specials, setActiveTab }) => (
  <ScrollView showsVerticalScrollIndicator={false}>
    <View style={styles.heroSection}>
      <Text style={styles.heroTitle}>بيت الزعفران</Text>
      <Text style={styles.heroSubtitle}>Experience True Arabian Hospitality</Text>
      <TouchableOpacity style={styles.heroButton} onPress={() => setActiveTab('menu')}>
        <Text style={styles.heroButtonText}>View Menu →</Text>
      </TouchableOpacity>
    </View>

    {/* Combined Arabic Food Display - Menu Spread */}
    <View style={styles.combinedImageContainer}>
      <Image source={{ uri: COMBINED_MENU_IMAGE }} style={styles.combinedImage} />
      <View style={styles.combinedImageOverlay}>
        <Text style={styles.combinedImageText}>Our Signature Dishes</Text>
        <Text style={styles.combinedImageSubtext}>Authentic Arabian Cuisine</Text>
      </View>
    </View>

    <View style={styles.quickActions}>
      <TouchableOpacity style={styles.quickAction} onPress={() => setActiveTab('cart')}>
        <Text style={styles.quickIcon}>🛒</Text>
        <Text style={styles.quickLabel}>Cart</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.quickAction} onPress={() => setActiveTab('reservations')}>
        <Text style={styles.quickIcon}>📅</Text>
        <Text style={styles.quickLabel}>Reserve</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.quickAction} onPress={() => setActiveTab('orders')}>
        <Text style={styles.quickIcon}>📦</Text>
        <Text style={styles.quickLabel}>Orders</Text>
      </TouchableOpacity>
    </View>

    <Text style={styles.sectionTitle}>🔥 Today's Specials</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.specialsScroll}>
      {specials.map(item => (
        <View key={item.id} style={styles.specialCard}>
          <View style={styles.specialIconContainer}>
            <Text style={styles.specialIcon}>🍽️</Text>
          </View>
          <Text style={styles.specialArabic}>{item.arabicName}</Text>
          <Text style={styles.specialName}>{item.name}</Text>
          <Text style={styles.specialPrice}>AED {item.price}</Text>
        </View>
      ))}
    </ScrollView>

    <View style={styles.qrInfoCard}>
      <Text style={styles.qrInfoTitle}>📱 Scan to Order</Text>
      <Text style={styles.qrInfoText}>Scan QR code on your table to view menu and place order instantly</Text>
    </View>
  </ScrollView>
);

const MenuTab = ({ categories, selectedCategory, setSelectedCategory, searchQuery, setSearchQuery, filteredItems, addToCart }) => (
  <View style={styles.menuContainer}>
    <View style={styles.searchBar}>
      <Text style={styles.searchIcon}>🔍</Text>
      <TextInput 
        style={styles.searchInput} 
        placeholder="Search menu..." 
        placeholderTextColor="#666"
        value={searchQuery} 
        onChangeText={setSearchQuery} 
      />
    </View>

    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesRow}>
      {categories.map(cat => (
        <TouchableOpacity 
          key={cat} 
          style={[styles.categoryChip, selectedCategory === cat && styles.categoryChipActive]} 
          onPress={() => setSelectedCategory(cat)}>
          <Text style={[styles.categoryChipText, selectedCategory === cat && styles.categoryChipTextActive]}>{cat}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>

    <FlatList
      data={filteredItems}
      keyExtractor={item => item.id.toString()}
      showsVerticalScrollIndicator={false}
      renderItem={({ item }) => (
        <View style={styles.menuItemCard}>
          <View style={styles.menuItemIcon}>
            <Text style={styles.menuItemIconText}>🍽️</Text>
          </View>
          <View style={styles.menuItemDetails}>
            <Text style={styles.menuItemArabic}>{item.arabicName}</Text>
            <Text style={styles.menuItemName}>{item.name}</Text>
            <Text style={styles.menuItemDesc} numberOfLines={2}>{item.description}</Text>
            <View style={styles.menuItemFooter}>
              <Text style={styles.menuItemPrice}>AED {item.price}</Text>
              <TouchableOpacity style={styles.addButton} onPress={() => addToCart(item)}>
                <Text style={styles.addButtonText}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}
    />
  </View>
);

const CartTab = () => {
  const { cart, updateCartQuantity, removeFromCart, placeOrder } = useContext(AppContext);
  const [showCheckout, setShowCheckout] = useState(false);
  
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const deliveryFee = 15;
  const tax = subtotal * 0.05;
  const total = subtotal + deliveryFee + tax;

  if (cart.length === 0) {
    return (
      <View style={styles.emptyState}>
        <Text style={styles.emptyEmoji}>🛒</Text>
        <Text style={styles.emptyText}>Your cart is empty</Text>
      </View>
    );
  }

  if (showCheckout) {
    return <CheckoutScreen cart={cart} subtotal={subtotal} deliveryFee={deliveryFee} tax={tax} total={total} placeOrder={placeOrder} onBack={() => setShowCheckout(false)} />;
  }

  return (
    <View style={styles.cartContainer}>
      <FlatList
        data={cart}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.cartItem}>
            <View style={styles.cartItemIcon}>
              <Text style={styles.cartItemIconText}>🍽️</Text>
            </View>
            <View style={styles.cartItemDetails}>
              <Text style={styles.cartItemName}>{item.name}</Text>
              <Text style={styles.cartItemPrice}>AED {item.price}</Text>
              <View style={styles.quantityControl}>
                <TouchableOpacity style={styles.qtyButton} onPress={() => updateCartQuantity(item.id, -1)}>
                  <Text style={styles.qtyButtonText}>-</Text>
                </TouchableOpacity>
                <Text style={styles.qtyValue}>{item.quantity}</Text>
                <TouchableOpacity style={styles.qtyButton} onPress={() => updateCartQuantity(item.id, 1)}>
                  <Text style={styles.qtyButtonText}>+</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.removeButton} onPress={() => removeFromCart(item.id)}>
                  <Text style={styles.removeText}>Remove</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
      />
      <View style={styles.cartSummary}>
        <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Subtotal</Text><Text style={styles.summaryValue}>AED {subtotal.toFixed(2)}</Text></View>
        <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Delivery Fee</Text><Text style={styles.summaryValue}>AED {deliveryFee.toFixed(2)}</Text></View>
        <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Tax (5%)</Text><Text style={styles.summaryValue}>AED {tax.toFixed(2)}</Text></View>
        <View style={[styles.summaryRow, styles.totalRow]}><Text style={styles.totalLabel}>Total</Text><Text style={styles.totalValue}>AED {total.toFixed(2)}</Text></View>
        <TouchableOpacity style={styles.checkoutBtn} onPress={() => setShowCheckout(true)}>
          <Text style={styles.checkoutBtnText}>Proceed to Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const CheckoutScreen = ({ cart, subtotal, deliveryFee, tax, total, placeOrder, onBack }) => {
  const [orderType, setOrderType] = useState('Dine In');
  const [address, setAddress] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');

  const paymentMethods = [
    { id: 'cod', name: 'Cash on Delivery', icon: '💵', description: 'Pay when you receive' },
    { id: 'card', name: 'Credit / Debit Card', icon: '💳', description: 'Visa, Mastercard, etc.' },
    { id: 'apple', name: 'Apple Pay', icon: '📱', description: 'Fast and secure' },
    { id: 'tabby', name: 'Tabby (Pay in 4)', icon: '📦', description: 'Split payments' },
  ];

  return (
    <ScrollView style={styles.checkoutContainer}>
      <TouchableOpacity onPress={onBack}><Text style={styles.backBtn}>← Back to Cart</Text></TouchableOpacity>
      <Text style={styles.checkoutTitle}>Checkout</Text>

      <View style={styles.checkoutSection}>
        <Text style={styles.sectionLabel}>Order Type</Text>
        <View style={styles.orderTypeRow}>
          {['Dine In', 'Takeaway', 'Delivery'].map(type => (
            <TouchableOpacity key={type} style={[styles.typeOption, orderType === type && styles.typeActive]} onPress={() => setOrderType(type)}>
              <Text style={[styles.typeText, orderType === type && styles.typeTextActive]}>{type}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {orderType === 'Delivery' && (
        <View style={styles.checkoutSection}>
          <Text style={styles.sectionLabel}>Delivery Address</Text>
          <TextInput style={styles.addressInput} placeholder="Enter your address" placeholderTextColor="#666" value={address} onChangeText={setAddress} multiline />
        </View>
      )}

      <View style={styles.checkoutSection}>
        <Text style={styles.sectionLabel}>Special Instructions</Text>
        <TextInput style={styles.addressInput} placeholder="Any special requests?" placeholderTextColor="#666" value={specialInstructions} onChangeText={setSpecialInstructions} />
      </View>

      <View style={styles.checkoutSection}>
        <Text style={styles.sectionLabel}>Payment Method</Text>
        {paymentMethods.map(method => (
          <TouchableOpacity 
            key={method.id}
            style={[styles.paymentOption, paymentMethod === method.name && styles.paymentOptionActive]} 
            onPress={() => setPaymentMethod(method.name)}>
            <View style={styles.paymentIconContainer}>
              <Text style={styles.paymentIcon}>{method.icon}</Text>
            </View>
            <View style={styles.paymentInfo}>
              <Text style={[styles.paymentName, paymentMethod === method.name && styles.paymentNameActive]}>{method.name}</Text>
              <Text style={styles.paymentDescription}>{method.description}</Text>
            </View>
            <View style={styles.paymentRadio}>
              <View style={[styles.radioOuter, paymentMethod === method.name && styles.radioOuterActive]}>
                {paymentMethod === method.name && <View style={styles.radioInner} />}
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.checkoutSection}>
        <Text style={styles.sectionLabel}>Order Summary</Text>
        {cart.map(item => (
          <View key={item.id} style={styles.orderSummaryItem}>
            <Text style={styles.summaryItemName}>{item.quantity}x {item.name}</Text>
            <Text style={styles.summaryItemPrice}>AED {(item.price * item.quantity).toFixed(2)}</Text>
          </View>
        ))}
        <View style={styles.divider} />
        <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Subtotal</Text><Text style={styles.summaryValue}>AED {subtotal.toFixed(2)}</Text></View>
        <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Delivery</Text><Text style={styles.summaryValue}>AED {deliveryFee.toFixed(2)}</Text></View>
        <View style={styles.summaryRow}><Text style={styles.summaryLabel}>Tax</Text><Text style={styles.summaryValue}>AED {tax.toFixed(2)}</Text></View>
        <View style={[styles.summaryRow, styles.totalRow]}><Text style={styles.totalLabel}>Total</Text><Text style={styles.totalValue}>AED {total.toFixed(2)}</Text></View>
      </View>

      <TouchableOpacity style={styles.placeOrderBtn} onPress={() => placeOrder({ orderType, address, specialInstructions, paymentMethod })}>
        <Text style={styles.placeOrderText}>Pay AED {total.toFixed(2)} via {paymentMethod}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

// ========== RESERVATION SCREEN WITH QR CODE ==========
const ReservationScreen = () => {
  const { makeReservation, tables } = useContext(AppContext);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('19:00');
  const [guests, setGuests] = useState('2');
  const [selectedTable, setSelectedTable] = useState(null);
  const [showQR, setShowQR] = useState(false);
  const [reservationData, setReservationData] = useState(null);

  const availableTables = tables.filter(t => t.status === 'available' && t.capacity >= parseInt(guests));

  const handleReservation = () => {
    if (!selectedTable) {
      Alert.alert('Error', 'Please select a table');
      return;
    }
    
    const reservationDetails = {
      date,
      time,
      guests: parseInt(guests),
      tableNumber: selectedTable.number,
      tableCapacity: selectedTable.capacity
    };
    
    makeReservation(reservationDetails);
    setReservationData(reservationDetails);
    setShowQR(true);
  };

  const shareQR = async () => {
    try {
      await Share.share({
        message: `Your reservation at Saffron House!\nTable ${reservationData?.tableNumber}\nDate: ${reservationData?.date}\nTime: ${reservationData?.time}\nGuests: ${reservationData?.guests}\n\nShow this QR code at the restaurant.`,
      });
    } catch (error) {
      Alert.alert('Error', 'Could not share');
    }
  };

  if (showQR && reservationData) {
    return (
      <ScrollView style={styles.qrContainer}>
        <TouchableOpacity onPress={() => setShowQR(false)} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        
        <View style={styles.qrCard}>
          <Text style={styles.qrTitle}>Reservation Confirmed! 🎉</Text>
          <View style={styles.qrCodeWrapper}>
            <QRCode
              value={`RESERVATION:${reservationData.tableNumber}|${reservationData.date}|${reservationData.time}|${reservationData.guests}`}
              size={200}
              color="#D4AF37"
              backgroundColor="#1A1A1A"
            />
          </View>
          
          <View style={styles.reservationDetailsCard}>
            <Text style={styles.reservationDetailTitle}>Reservation Details</Text>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Table Number:</Text>
              <Text style={styles.reservationDetailValue}>Table {reservationData.tableNumber}</Text>
            </View>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Date:</Text>
              <Text style={styles.reservationDetailValue}>{reservationData.date}</Text>
            </View>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Time:</Text>
              <Text style={styles.reservationDetailValue}>{reservationData.time}</Text>
            </View>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Guests:</Text>
              <Text style={styles.reservationDetailValue}>{reservationData.guests}</Text>
            </View>
          </View>
          
          <Text style={styles.qrInstruction}>
            Show this QR code at the restaurant entrance for quick check-in
          </Text>
          
          <TouchableOpacity style={styles.shareButton} onPress={shareQR}>
            <Text style={styles.shareButtonText}>📤 Share Reservation</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.reservationContainer}>
      <Text style={styles.reservationTitle}>Reserve a Table</Text>
      
      <View style={styles.reservationSection}>
        <Text style={styles.sectionLabel}>Date</Text>
        <TextInput style={styles.reservationInput} value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor="#666" />
      </View>
      
      <View style={styles.reservationSection}>
        <Text style={styles.sectionLabel}>Time</Text>
        <TextInput style={styles.reservationInput} value={time} onChangeText={setTime} placeholder="HH:MM" placeholderTextColor="#666" />
      </View>
      
      <View style={styles.reservationSection}>
        <Text style={styles.sectionLabel}>Number of Guests</Text>
        <TextInput style={styles.reservationInput} value={guests} onChangeText={setGuests} keyboardType="numeric" placeholder="2" placeholderTextColor="#666" />
      </View>
      
      <View style={styles.reservationSection}>
        <Text style={styles.sectionLabel}>Select Table</Text>
        <View style={styles.tablesGrid}>
          {availableTables.map(table => (
            <TouchableOpacity
              key={table.id}
              style={[styles.tableCard, selectedTable?.number === table.number && styles.tableCardSelected]}
              onPress={() => setSelectedTable(table)}>
              <Text style={styles.tableNumber}>Table {table.number}</Text>
              <Text style={styles.tableCapacity}>🪑 {table.capacity} seats</Text>
            </TouchableOpacity>
          ))}
        </View>
        {availableTables.length === 0 && (
          <Text style={styles.noTablesText}>No tables available for {guests} guests</Text>
        )}
      </View>
      
      <TouchableOpacity style={styles.confirmReservationButton} onPress={handleReservation}>
        <Text style={styles.confirmReservationText}>Confirm Reservation</Text>
      </TouchableOpacity>
      
      <View style={styles.tableQrInfo}>
        <Text style={styles.tableQrInfoTitle}>📱 Table QR Code</Text>
        <Text style={styles.tableQrInfoText}>Each table has a QR code. Scan to view menu and place orders without waiting for staff!</Text>
      </View>
    </ScrollView>
  );
};

const OrdersTab = ({ orders }) => {
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showOrderQR, setShowOrderQR] = useState(false);
  
  const statusColors = {
    Pending: '#FFA500',
    Preparing: '#4CAF50',
    Ready: '#2196F3',
    Delivered: '#888'
  };

  const shareOrderQR = async (order) => {
    try {
      await Share.share({
        message: `Your order ${order.id} at Saffron House is ${order.status}\nTotal: AED ${order.total.toFixed(2)}\nTrack your order: ${order.id}`,
      });
    } catch (error) {
      Alert.alert('Error', 'Could not share');
    }
  };

  if (showOrderQR && selectedOrder) {
    return (
      <ScrollView style={styles.qrContainer}>
        <TouchableOpacity onPress={() => setShowOrderQR(false)} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        
        <View style={styles.qrCard}>
          <Text style={styles.qrTitle}>Order Tracking QR</Text>
          <View style={styles.qrCodeWrapper}>
            <QRCode
              value={`ORDER:${selectedOrder.id}|STATUS:${selectedOrder.status}|TOTAL:${selectedOrder.total}`}
              size={200}
              color="#D4AF37"
              backgroundColor="#1A1A1A"
            />
          </View>
          
          <View style={styles.reservationDetailsCard}>
            <Text style={styles.reservationDetailTitle}>Order Details</Text>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Order ID:</Text>
              <Text style={styles.reservationDetailValue}>{selectedOrder.id}</Text>
            </View>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Status:</Text>
              <Text style={[styles.reservationDetailValue, { color: statusColors[selectedOrder.status] }]}>{selectedOrder.status}</Text>
            </View>
            <View style={styles.reservationDetailRow}>
              <Text style={styles.reservationDetailLabel}>Total:</Text>
              <Text style={styles.reservationDetailValue}>AED {selectedOrder.total.toFixed(2)}</Text>
            </View>
          </View>
          
          <Text style={styles.qrInstruction}>
            Scan this QR code at the pickup counter to collect your order
          </Text>
          
          <TouchableOpacity style={styles.shareButton} onPress={() => shareOrderQR(selectedOrder)}>
            <Text style={styles.shareButtonText}>📤 Share Order</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }

  if (orders.length === 0) {
    return (
      <View style={styles.emptyState}>
        <Text style={styles.emptyEmoji}>📦</Text>
        <Text style={styles.emptyText}>No orders yet</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={orders}
      keyExtractor={item => item.id}
      contentContainerStyle={styles.ordersList}
      renderItem={({ item }) => (
        <TouchableOpacity style={styles.orderCard} onPress={() => { setSelectedOrder(item); setShowOrderQR(true); }}>
          <View style={styles.orderHeader}>
            <Text style={styles.orderId}>{item.id}</Text>
            <View style={[styles.statusBadge, { backgroundColor: statusColors[item.status] }]}>
              <Text style={styles.statusText}>{item.status}</Text>
            </View>
          </View>
          <Text style={styles.orderDate}>{new Date(item.date).toLocaleDateString()}</Text>
          <Text style={styles.orderItems}>{item.items.length} items • AED {item.total.toFixed(2)}</Text>
          <Text style={styles.orderPayment}>Paid via: {item.paymentMethod || 'Cash on Delivery'}</Text>
          <View style={styles.orderQRBadge}>
            <Text style={styles.orderQRBadgeText}>📱 Tap for QR</Text>
          </View>
        </TouchableOpacity>
      )}
    />
  );
};

const ProfileTab = ({ currentUser }) => (
  <ScrollView style={styles.profileContainer}>
    <View style={styles.profileHeader}>
      <View style={styles.avatar}><Text style={styles.avatarText}>👤</Text></View>
      <Text style={styles.profileName}>{currentUser?.name}</Text>
      <Text style={styles.profileEmail}>{currentUser?.email}</Text>
    </View>
    <View style={styles.profileInfo}>
      <View style={styles.infoRow}><Text style={styles.infoLabel}>Phone</Text><Text style={styles.infoValue}>{currentUser?.phone || 'Not set'}</Text></View>
      <View style={styles.infoRow}><Text style={styles.infoLabel}>Member Since</Text><Text style={styles.infoValue}>2024</Text></View>
    </View>
  </ScrollView>
);

// ========== MANAGER DASHBOARD ==========
const ManagerDashboard = () => {
  const [activeView, setActiveView] = useState('dashboard');
  const { orders, reservations, menuItems, tables, updateOrderStatus, updateMenuItem, addMenuItem, deleteMenuItem, logout } = useContext(AppContext);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [editForm, setEditForm] = useState({ name: '', arabicName: '', price: '', category: '', description: '' });

  const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);
  const pendingOrders = orders.filter(o => o.status === 'Pending').length;

  const handleEdit = (item) => {
    setSelectedItem(item);
    setEditForm({
      name: item.name,
      arabicName: item.arabicName,
      price: item.price.toString(),
      category: item.category,
      description: item.description,
    });
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    updateMenuItem(selectedItem.id, {
      name: editForm.name,
      arabicName: editForm.arabicName,
      price: parseFloat(editForm.price),
      category: editForm.category,
      description: editForm.description,
    });
    setShowEditModal(false);
    Alert.alert('Success', 'Item updated');
  };

  const handleAdd = () => {
    addMenuItem({
      name: editForm.name,
      arabicName: editForm.arabicName,
      price: parseFloat(editForm.price),
      category: editForm.category,
      description: editForm.description,
      image: 'https://i.imgur.com/placeholder.jpg',
      available: true,
      isSpecial: false,
    });
    setShowAddModal(false);
    setEditForm({ name: '', arabicName: '', price: '', category: '', description: '' });
    Alert.alert('Success', 'Item added');
  };

  const handleDelete = (itemId) => {
    Alert.alert('Confirm', 'Delete this item?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', onPress: () => { deleteMenuItem(itemId); Alert.alert('Deleted'); } }
    ]);
  };

  const updateStatus = (orderId, newStatus) => {
    updateOrderStatus(orderId, newStatus);
    Alert.alert('Updated', `Order status changed to ${newStatus}`);
  };

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <View>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}><Text style={styles.statNumber}>{orders.length}</Text><Text style={styles.statLabel}>Total Orders</Text></View>
              <View style={styles.statCard}><Text style={styles.statNumber}>{pendingOrders}</Text><Text style={styles.statLabel}>Pending</Text></View>
              <View style={styles.statCard}><Text style={styles.statNumber}>{reservations.length}</Text><Text style={styles.statLabel}>Reservations</Text></View>
              <View style={styles.statCard}><Text style={styles.statNumber}>AED {totalRevenue}</Text><Text style={styles.statLabel}>Revenue</Text></View>
            </View>

            <Text style={styles.managerSectionTitle}>Quick Actions</Text>
            <View style={styles.quickActionsGrid}>
              <TouchableOpacity style={styles.actionCard} onPress={() => setActiveView('orders')}><Text style={styles.actionIcon}>📋</Text><Text style={styles.actionText}>Orders</Text></TouchableOpacity>
              <TouchableOpacity style={styles.actionCard} onPress={() => setActiveView('menu')}><Text style={styles.actionIcon}>🍽️</Text><Text style={styles.actionText}>Menu</Text></TouchableOpacity>
              <TouchableOpacity style={styles.actionCard} onPress={() => setActiveView('reservations')}><Text style={styles.actionIcon}>📅</Text><Text style={styles.actionText}>Reservations</Text></TouchableOpacity>
              <TouchableOpacity style={styles.actionCard} onPress={() => setActiveView('tables')}><Text style={styles.actionIcon}>🪑</Text><Text style={styles.actionText}>Tables</Text></TouchableOpacity>
            </View>

            <Text style={styles.managerSectionTitle}>Recent Orders</Text>
            {orders.slice(0, 3).map(order => (
              <View key={order.id} style={styles.recentOrder}>
                <View><Text style={styles.recentOrderId}>{order.id}</Text><Text style={styles.recentOrderName}>{order.userName}</Text></View>
                <View style={[styles.statusDot, { backgroundColor: order.status === 'Pending' ? '#FFA500' : '#4CAF50' }]}><Text style={styles.statusDotText}>{order.status}</Text></View>
              </View>
            ))}
          </View>
        );
      case 'orders':
        return (
          <View>
            <Text style={styles.managerSectionTitle}>All Orders</Text>
            {orders.map(order => (
              <View key={order.id} style={styles.orderManageCard}>
                <View><Text style={styles.orderIdText}>{order.id}</Text><Text style={styles.orderCustomer}>{order.userName}</Text><Text style={styles.orderTotal}>AED {order.total?.toFixed(2)}</Text></View>
                <View>
                  <View style={[styles.orderStatusBadge, { backgroundColor: order.status === 'Pending' ? '#FFA500' : order.status === 'Preparing' ? '#4CAF50' : '#2196F3' }]}><Text style={styles.orderStatusText}>{order.status}</Text></View>
                  <View style={styles.statusButtons}>
                    {order.status === 'Pending' && <TouchableOpacity onPress={() => updateStatus(order.id, 'Preparing')}><Text style={styles.statusBtn}>Prepare</Text></TouchableOpacity>}
                    {order.status === 'Preparing' && <TouchableOpacity onPress={() => updateStatus(order.id, 'Ready')}><Text style={styles.statusBtn}>Ready</Text></TouchableOpacity>}
                    {order.status === 'Ready' && <TouchableOpacity onPress={() => updateStatus(order.id, 'Delivered')}><Text style={styles.statusBtn}>Deliver</Text></TouchableOpacity>}
                  </View>
                </View>
              </View>
            ))}
          </View>
        );
      case 'menu':
        return (
          <View>
            <TouchableOpacity style={styles.addItemBtn} onPress={() => setShowAddModal(true)}><Text style={styles.addItemBtnText}>+ Add New Item</Text></TouchableOpacity>
            {menuItems.map(item => (
              <View key={item.id} style={styles.menuManageCard}>
                <View><Text style={styles.menuManageName}>{item.name}</Text><Text style={styles.menuManageArabic}>{item.arabicName}</Text><Text style={styles.menuManagePrice}>AED {item.price}</Text></View>
                <View style={styles.menuManageActions}>
                  <TouchableOpacity onPress={() => handleEdit(item)}><Text style={styles.editBtn}>Edit</Text></TouchableOpacity>
                  <TouchableOpacity onPress={() => handleDelete(item.id)}><Text style={styles.deleteBtn}>Delete</Text></TouchableOpacity>
                </View>
              </View>
            ))}
          </View>
        );
      case 'reservations':
        return (
          <View>
            <Text style={styles.managerSectionTitle}>All Reservations</Text>
            {reservations.map(res => (
              <View key={res.id} style={styles.reservationCard}>
                <Text style={styles.reservationId}>{res.id}</Text>
                <Text style={styles.reservationName}>{res.userName}</Text>
                <Text style={styles.reservationDetails}>{res.date} at {res.time} • {res.guests} guests • Table {res.tableNumber}</Text>
                <View style={styles.confirmedBadge}><Text style={styles.confirmedText}>✓ Confirmed</Text></View>
              </View>
            ))}
          </View>
        );
      case 'tables':
        return (
          <View>
            <Text style={styles.managerSectionTitle}>Table Management</Text>
            <View style={styles.tablesGridManager}>
              {tables.map(table => (
                <View key={table.id} style={[styles.tableCardManager, table.status === 'booked' && styles.tableBooked]}>
                  <Text style={styles.tableNumberManager}>Table {table.number}</Text>
                  <Text style={styles.tableCapacityManager}>Capacity: {table.capacity} seats</Text>
                  <View style={[styles.tableStatus, table.status === 'available' ? styles.statusAvailable : styles.statusBooked]}>
                    <Text style={styles.tableStatusText}>{table.status === 'available' ? 'Available' : 'Booked'}</Text>
                  </View>
                </View>
              ))}
            </View>
            <View style={styles.tableQrInfo}>
              <Text style={styles.tableQrInfoTitle}>📱 Table QR Codes</Text>
              <Text style={styles.tableQrInfoText}>Each table has a unique QR code. Customers scan to view menu and place orders.</Text>
            </View>
          </View>
        );
      default: return null;
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.managerHeader}>
        <View><Text style={styles.managerTitle}>Manager Dashboard</Text><Text style={styles.managerSubtitle}>Saffron House Restaurant</Text></View>
        <TouchableOpacity onPress={logout}><Text style={styles.managerLogout}>Logout</Text></TouchableOpacity>
      </View>

      <View style={styles.managerNav}>
        {['dashboard', 'orders', 'menu', 'reservations', 'tables'].map(view => (
          <TouchableOpacity key={view} style={[styles.managerNavItem, activeView === view && styles.managerNavActive]} onPress={() => setActiveView(view)}>
            <Text style={[styles.managerNavText, activeView === view && styles.managerNavTextActive]}>{view.charAt(0).toUpperCase() + view.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.managerContent}>{renderContent()}</ScrollView>

      {/* Edit Modal */}
      <Modal visible={showEditModal} transparent animationType="fade">
        <View style={styles.modalOverlay}><View style={styles.modalContainer}>
          <Text style={styles.modalTitle}>Edit Menu Item</Text>
          <TextInput style={styles.modalInput} placeholder="Name" value={editForm.name} onChangeText={t => setEditForm({...editForm, name: t})} />
          <TextInput style={styles.modalInput} placeholder="Arabic Name" value={editForm.arabicName} onChangeText={t => setEditForm({...editForm, arabicName: t})} />
          <TextInput style={styles.modalInput} placeholder="Price" value={editForm.price} onChangeText={t => setEditForm({...editForm, price: t})} keyboardType="numeric" />
          <TextInput style={styles.modalInput} placeholder="Category" value={editForm.category} onChangeText={t => setEditForm({...editForm, category: t})} />
          <TextInput style={styles.modalInput} placeholder="Description" value={editForm.description} onChangeText={t => setEditForm({...editForm, description: t})} />
          <View style={styles.modalButtons}><TouchableOpacity onPress={() => setShowEditModal(false)}><Text style={styles.modalCancel}>Cancel</Text></TouchableOpacity><TouchableOpacity onPress={handleSaveEdit}><Text style={styles.modalSave}>Save</Text></TouchableOpacity></View>
        </View></View>
      </Modal>

      {/* Add Modal */}
      <Modal visible={showAddModal} transparent animationType="fade">
        <View style={styles.modalOverlay}><View style={styles.modalContainer}>
          <Text style={styles.modalTitle}>Add New Item</Text>
          <TextInput style={styles.modalInput} placeholder="Name" value={editForm.name} onChangeText={t => setEditForm({...editForm, name: t})} />
          <TextInput style={styles.modalInput} placeholder="Arabic Name" value={editForm.arabicName} onChangeText={t => setEditForm({...editForm, arabicName: t})} />
          <TextInput style={styles.modalInput} placeholder="Price" value={editForm.price} onChangeText={t => setEditForm({...editForm, price: t})} keyboardType="numeric" />
          <TextInput style={styles.modalInput} placeholder="Category" value={editForm.category} onChangeText={t => setEditForm({...editForm, category: t})} />
          <TextInput style={styles.modalInput} placeholder="Description" value={editForm.description} onChangeText={t => setEditForm({...editForm, description: t})} />
          <View style={styles.modalButtons}><TouchableOpacity onPress={() => setShowAddModal(false)}><Text style={styles.modalCancel}>Cancel</Text></TouchableOpacity><TouchableOpacity onPress={handleAdd}><Text style={styles.modalSave}>Add</Text></TouchableOpacity></View>
        </View></View>
      </Modal>
    </SafeAreaView>
  );
};

// ========== STYLES ==========
const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#0A0A0A' },

  // Auth
  authContainer: { flexGrow: 1, justifyContent: 'center', padding: 20 },
  logoSection: { alignItems: 'center', marginBottom: 40 },
  logoCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#D4AF37', justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  logoEmoji: { fontSize: 40 },
  restaurantArabic: { fontSize: 32, color: '#FFF', fontWeight: '300', writingDirection: 'rtl', marginBottom: 4 },
  restaurantEnglish: { fontSize: 12, color: '#D4AF37', letterSpacing: 2, marginBottom: 8 },
  tagline: { fontSize: 12, color: '#666' },
  authCard: { backgroundColor: '#1A1A1A', borderRadius: 20, padding: 24 },
  authToggle: { flexDirection: 'row', marginBottom: 24 },
  toggleButton: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: '#333' },
  toggleActive: { borderBottomColor: '#D4AF37' },
  toggleText: { color: '#666', fontSize: 16 },
  toggleTextActive: { color: '#D4AF37' },
  authInput: { backgroundColor: '#2A2A2A', borderRadius: 12, padding: 14, color: '#FFF', marginBottom: 12, fontSize: 14 },
  passwordWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#2A2A2A', borderRadius: 12, marginBottom: 12, paddingRight: 12 },
  showHide: { color: '#D4AF37', fontSize: 12 },
  roleSelect: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  roleOption: { flex: 1, paddingVertical: 12, alignItems: 'center', backgroundColor: '#2A2A2A', borderRadius: 12 },
  roleActive: { backgroundColor: '#D4AF37' },
  roleText: { color: '#888' },
  roleTextActive: { color: '#0A0A0A', fontWeight: '600' },
  authButton: { backgroundColor: '#D4AF37', paddingVertical: 16, borderRadius: 12, alignItems: 'center' },
  authButtonText: { color: '#0A0A0A', fontSize: 16, fontWeight: '600' },

  // Customer Header
  customerHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 16 },
  greeting: { color: '#888', fontSize: 12 },
  userName: { color: '#D4AF37', fontSize: 18, fontWeight: '600' },
  logoutBtn: { color: '#FF4444', fontSize: 14 },

  // Bottom Navigation
  bottomNav: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#1A1A1A', backgroundColor: '#0A0A0A' },
  navItem: { alignItems: 'center', position: 'relative' },
  navIcon: { fontSize: 22, color: '#666' },
  navIconActive: { color: '#D4AF37' },
  navLabel: { fontSize: 10, color: '#666', marginTop: 2 },
  navLabelActive: { color: '#D4AF37' },
  navBadge: { position: 'absolute', top: -5, right: -10, backgroundColor: '#D4AF37', minWidth: 18, height: 18, borderRadius: 9, justifyContent: 'center', alignItems: 'center' },
  navBadgeText: { color: '#0A0A0A', fontSize: 10, fontWeight: 'bold' },
  content: { flex: 1 },

  // Home
  heroSection: { alignItems: 'center', paddingVertical: 30 },
  heroTitle: { fontSize: 28, color: '#D4AF37', writingDirection: 'rtl', marginBottom: 8 },
  heroSubtitle: { fontSize: 14, color: '#FFF', marginBottom: 20 },
  heroButton: { backgroundColor: '#D4AF37', paddingHorizontal: 30, paddingVertical: 12, borderRadius: 30 },
  heroButtonText: { color: '#0A0A0A', fontWeight: '600' },
  
  // Combined Image
  combinedImageContainer: { marginHorizontal: 20, marginVertical: 15, borderRadius: 20, overflow: 'hidden', position: 'relative' },
  combinedImage: { width: '100%', height: 180, resizeMode: 'cover' },
  combinedImageOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: 'rgba(0,0,0,0.6)', padding: 12 },
  combinedImageText: { color: '#D4AF37', fontSize: 18, fontWeight: 'bold' },
  combinedImageSubtext: { color: '#FFF', fontSize: 12 },
  
  quickActions: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 20, borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#1A1A1A', marginVertical: 10 },
  quickAction: { alignItems: 'center' },
  quickIcon: { fontSize: 28, marginBottom: 6 },
  quickLabel: { color: '#888', fontSize: 12 },
  sectionTitle: { color: '#FFF', fontSize: 18, fontWeight: '600', marginHorizontal: 20, marginTop: 20, marginBottom: 12 },
  specialsScroll: { paddingLeft: 20 },
  specialCard: { width: 150, backgroundColor: '#1A1A1A', borderRadius: 16, padding: 12, marginRight: 12, alignItems: 'center' },
  specialIconContainer: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#D4AF37', justifyContent: 'center', alignItems: 'center', marginBottom: 8 },
  specialIcon: { fontSize: 30 },
  specialArabic: { color: '#D4AF37', fontSize: 14, writingDirection: 'rtl' },
  specialName: { color: '#FFF', fontSize: 12, marginVertical: 2, textAlign: 'center' },
  specialPrice: { color: '#D4AF37', fontSize: 14, fontWeight: '600' },
  qrInfoCard: { backgroundColor: '#1A1A1A', margin: 20, padding: 16, borderRadius: 12, borderLeftWidth: 4, borderLeftColor: '#D4AF37' },
  qrInfoTitle: { color: '#D4AF37', fontSize: 14, fontWeight: '600', marginBottom: 6 },
  qrInfoText: { color: '#888', fontSize: 12 },

  // Menu
  menuContainer: { flex: 1 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1A1A1A', margin: 20, paddingHorizontal: 15, borderRadius: 12 },
  searchIcon: { fontSize: 16, color: '#666', marginRight: 10 },
  searchInput: { flex: 1, color: '#FFF', paddingVertical: 12 },
  categoriesRow: { paddingHorizontal: 20, marginBottom: 15 },
  categoryChip: { paddingHorizontal: 20, paddingVertical: 8, backgroundColor: '#1A1A1A', borderRadius: 20, marginRight: 10 },
  categoryChipActive: { backgroundColor: '#D4AF37' },
  categoryChipText: { color: '#888' },
  categoryChipTextActive: { color: '#0A0A0A', fontWeight: '600' },
  menuItemCard: { flexDirection: 'row', backgroundColor: '#1A1A1A', marginHorizontal: 20, marginBottom: 12, padding: 12, borderRadius: 16 },
  menuItemIcon: { width: 60, height: 60, borderRadius: 30, backgroundColor: '#D4AF37', justifyContent: 'center', alignItems: 'center' },
  menuItemIconText: { fontSize: 28 },
  menuItemDetails: { flex: 1, marginLeft: 12 },
  menuItemArabic: { color: '#D4AF37', fontSize: 14, writingDirection: 'rtl', marginBottom: 2 },
  menuItemName: { color: '#FFF', fontSize: 14, fontWeight: '500', marginBottom: 2 },
  menuItemDesc: { color: '#888', fontSize: 11, marginBottom: 8 },
  menuItemFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  menuItemPrice: { color: '#FFF', fontSize: 16, fontWeight: '600' },
  addButton: { backgroundColor: '#D4AF37', paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20 },
  addButtonText: { color: '#0A0A0A', fontWeight: '600', fontSize: 12 },

  // Cart
  cartContainer: { flex: 1 },
  cartItem: { flexDirection: 'row', backgroundColor: '#1A1A1A', marginHorizontal: 20, marginBottom: 12, padding: 12, borderRadius: 16 },
  cartItemIcon: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#D4AF37', justifyContent: 'center', alignItems: 'center' },
  cartItemIconText: { fontSize: 24 },
  cartItemDetails: { flex: 1, marginLeft: 12 },
  cartItemName: { color: '#FFF', fontSize: 14, fontWeight: '500' },
  cartItemPrice: { color: '#D4AF37', fontSize: 14, marginVertical: 4 },
  quantityControl: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  qtyButton: { width: 28, height: 28, backgroundColor: '#2A2A2A', borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  qtyButtonText: { color: '#FFF', fontSize: 16 },
  qtyValue: { color: '#FFF', marginHorizontal: 12 },
  removeButton: { marginLeft: 12 },
  removeText: { color: '#FF4444', fontSize: 12 },
  cartSummary: { backgroundColor: '#1A1A1A', padding: 20, borderTopWidth: 1, borderTopColor: '#2A2A2A' },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  summaryLabel: { color: '#888', fontSize: 14 },
  summaryValue: { color: '#FFF', fontSize: 14 },
  totalRow: { marginTop: 8, paddingTop: 8, borderTopWidth: 1, borderTopColor: '#2A2A2A' },
  totalLabel: { color: '#D4AF37', fontSize: 16, fontWeight: '600' },
  totalValue: { color: '#D4AF37', fontSize: 16, fontWeight: '600' },
  checkoutBtn: { backgroundColor: '#D4AF37', paddingVertical: 14, borderRadius: 12, alignItems: 'center', marginTop: 12 },
  checkoutBtnText: { color: '#0A0A0A', fontSize: 16, fontWeight: '600' },

  // Checkout
  checkoutContainer: { padding: 20 },
  backBtn: { color: '#D4AF37', fontSize: 16, marginBottom: 20 },
  checkoutTitle: { color: '#FFF', fontSize: 24, fontWeight: '600', marginBottom: 20 },
  checkoutSection: { marginBottom: 24 },
  sectionLabel: { color: '#D4AF37', fontSize: 14, marginBottom: 10 },
  orderTypeRow: { flexDirection: 'row', gap: 12 },
  typeOption: { flex: 1, paddingVertical: 12, backgroundColor: '#1A1A1A', borderRadius: 12, alignItems: 'center' },
  typeActive: { backgroundColor: '#D4AF37' },
  typeText: { color: '#888' },
  typeTextActive: { color: '#0A0A0A', fontWeight: '600' },
  addressInput: { backgroundColor: '#1A1A1A', borderRadius: 12, padding: 14, color: '#FFF', minHeight: 80, textAlignVertical: 'top' },
  paymentOption: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#1A1A1A', borderRadius: 12, padding: 12, marginBottom: 10, borderWidth: 1, borderColor: '#2A2A2A' },
  paymentOptionActive: { borderColor: '#D4AF37', backgroundColor: '#2A2A2A' },
  paymentIconContainer: { width: 40, alignItems: 'center' },
  paymentIcon: { fontSize: 24 },
  paymentInfo: { flex: 1, marginLeft: 8 },
  paymentName: { color: '#FFF', fontSize: 14, fontWeight: '500' },
  paymentNameActive: { color: '#D4AF37' },
  paymentDescription: { color: '#888', fontSize: 10, marginTop: 2 },
  paymentRadio: { width: 24, alignItems: 'center' },
  radioOuter: { width: 18, height: 18, borderRadius: 9, borderWidth: 2, borderColor: '#666', justifyContent: 'center', alignItems: 'center' },
  radioOuterActive: { borderColor: '#D4AF37' },
  radioInner: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#D4AF37' },
  orderSummaryItem: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  summaryItemName: { color: '#888', fontSize: 14 },
  summaryItemPrice: { color: '#FFF', fontSize: 14 },
  divider: { height: 1, backgroundColor: '#2A2A2A', marginVertical: 12 },
  placeOrderBtn: { backgroundColor: '#D4AF37', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 20, marginBottom: 40 },
  placeOrderText: { color: '#0A0A0A', fontSize: 16, fontWeight: '600' },

  // Reservation
  reservationContainer: { padding: 20 },
  reservationTitle: { color: '#D4AF37', fontSize: 24, fontWeight: '600', marginBottom: 20 },
  reservationSection: { marginBottom: 20 },
  reservationInput: { backgroundColor: '#1A1A1A', borderRadius: 12, padding: 14, color: '#FFF', fontSize: 14 },
  tablesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  tableCard: { flex: 1, minWidth: '45%', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: '#2A2A2A' },
  tableCardSelected: { borderColor: '#D4AF37', backgroundColor: '#2A2A2A' },
  tableNumber: { color: '#D4AF37', fontSize: 18, fontWeight: '600', marginBottom: 4 },
  tableCapacity: { color: '#888', fontSize: 12 },
  noTablesText: { color: '#FF4444', fontSize: 14, textAlign: 'center', marginTop: 10 },
  confirmReservationButton: { backgroundColor: '#D4AF37', paddingVertical: 16, borderRadius: 12, alignItems: 'center', marginTop: 20 },
  confirmReservationText: { color: '#0A0A0A', fontSize: 16, fontWeight: '600' },
  tableQrInfo: { backgroundColor: '#1A1A1A', marginTop: 20, padding: 16, borderRadius: 12 },
  tableQrInfoTitle: { color: '#D4AF37', fontSize: 14, fontWeight: '600', marginBottom: 6 },
  tableQrInfoText: { color: '#888', fontSize: 12 },

  // QR Code
  qrContainer: { padding: 20 },
  qrCard: { backgroundColor: '#1A1A1A', borderRadius: 20, padding: 24, alignItems: 'center' },
  qrTitle: { color: '#D4AF37', fontSize: 20, fontWeight: '600', marginBottom: 20 },
  qrCodeWrapper: { padding: 16, backgroundColor: '#1A1A1A', borderRadius: 16, marginBottom: 20 },
  reservationDetailsCard: { backgroundColor: '#2A2A2A', borderRadius: 12, padding: 16, width: '100%', marginBottom: 20 },
  reservationDetailTitle: { color: '#D4AF37', fontSize: 16, fontWeight: '600', marginBottom: 12 },
  reservationDetailRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  reservationDetailLabel: { color: '#888', fontSize: 14 },
  reservationDetailValue: { color: '#FFF', fontSize: 14, fontWeight: '500' },
  qrInstruction: { color: '#888', fontSize: 12, textAlign: 'center', marginBottom: 20 },
  shareButton: { backgroundColor: '#D4AF37', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 12 },
  shareButtonText: { color: '#0A0A0A', fontSize: 14, fontWeight: '600' },
  backButton: { marginBottom: 20 },
  backButtonText: { color: '#D4AF37', fontSize: 16 },

  // Orders
  ordersList: { padding: 20 },
  orderCard: { backgroundColor: '#1A1A1A', borderRadius: 16, padding: 16, marginBottom: 12 },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  orderId: { color: '#D4AF37', fontSize: 14, fontWeight: '600' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  statusText: { color: '#FFF', fontSize: 10, fontWeight: '600' },
  orderDate: { color: '#666', fontSize: 12, marginBottom: 4 },
  orderItems: { color: '#FFF', fontSize: 14 },
  orderPayment: { color: '#888', fontSize: 11, marginTop: 6 },
  orderQRBadge: { marginTop: 10, alignSelf: 'flex-start', backgroundColor: '#2A2A2A', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  orderQRBadgeText: { color: '#D4AF37', fontSize: 10 },

  // Profile
  profileContainer: { padding: 20 },
  profileHeader: { alignItems: 'center', marginBottom: 30 },
  avatar: { width: 80, height: 80, backgroundColor: '#1A1A1A', borderRadius: 40, justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  avatarText: { fontSize: 40 },
  profileName: { color: '#FFF', fontSize: 20, fontWeight: '600' },
  profileEmail: { color: '#888', fontSize: 14, marginTop: 4 },
  profileInfo: { backgroundColor: '#1A1A1A', borderRadius: 16, padding: 20 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  infoLabel: { color: '#888', fontSize: 14 },
  infoValue: { color: '#FFF', fontSize: 14 },

  // Manager Dashboard
  managerHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#1A1A1A' },
  managerTitle: { color: '#D4AF37', fontSize: 20, fontWeight: '600' },
  managerSubtitle: { color: '#888', fontSize: 12 },
  managerLogout: { color: '#FF4444', fontSize: 14 },
  managerNav: { flexDirection: 'row', backgroundColor: '#1A1A1A', marginHorizontal: 20, marginVertical: 16, borderRadius: 12, padding: 4 },
  managerNavItem: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 8 },
  managerNavActive: { backgroundColor: '#D4AF37' },
  managerNavText: { color: '#888', fontSize: 14 },
  managerNavTextActive: { color: '#0A0A0A', fontWeight: '600' },
  managerContent: { padding: 20 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  statCard: { flex: 1, minWidth: '45%', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 16, alignItems: 'center' },
  statNumber: { color: '#D4AF37', fontSize: 24, fontWeight: '600', marginBottom: 4 },
  statLabel: { color: '#888', fontSize: 12 },
  managerSectionTitle: { color: '#D4AF37', fontSize: 16, fontWeight: '600', marginBottom: 12, marginTop: 8 },
  quickActionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  actionCard: { flex: 1, minWidth: '45%', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 16, alignItems: 'center' },
  actionIcon: { fontSize: 28, marginBottom: 8 },
  actionText: { color: '#FFF', fontSize: 12 },
  recentOrder: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 12, marginBottom: 8 },
  recentOrderId: { color: '#D4AF37', fontSize: 14, fontWeight: '600' },
  recentOrderName: { color: '#888', fontSize: 12 },
  statusDot: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 20 },
  statusDotText: { color: '#FFF', fontSize: 10, fontWeight: '600' },
  orderManageCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 12, marginBottom: 12 },
  orderIdText: { color: '#D4AF37', fontSize: 14, fontWeight: '600' },
  orderCustomer: { color: '#FFF', fontSize: 12, marginTop: 2 },
  orderTotal: { color: '#D4AF37', fontSize: 14, marginTop: 4 },
  orderStatusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, marginBottom: 8 },
  orderStatusText: { color: '#FFF', fontSize: 10, fontWeight: '600' },
  statusButtons: { flexDirection: 'row', gap: 8 },
  statusBtn: { color: '#D4AF37', fontSize: 12 },
  addItemBtn: { backgroundColor: '#D4AF37', padding: 14, borderRadius: 12, alignItems: 'center', marginBottom: 20 },
  addItemBtnText: { color: '#0A0A0A', fontSize: 14, fontWeight: '600' },
  menuManageCard: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 12, marginBottom: 12 },
  menuManageName: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  menuManageArabic: { color: '#888', fontSize: 12, marginTop: 2 },
  menuManagePrice: { color: '#D4AF37', fontSize: 14, marginTop: 4 },
  menuManageActions: { flexDirection: 'row', gap: 12 },
  editBtn: { color: '#D4AF37', fontSize: 12 },
  deleteBtn: { color: '#FF4444', fontSize: 12 },
  reservationCard: { backgroundColor: '#1A1A1A', padding: 16, borderRadius: 12, marginBottom: 12 },
  reservationId: { color: '#D4AF37', fontSize: 14, fontWeight: '600' },
  reservationName: { color: '#FFF', fontSize: 14, marginTop: 4 },
  reservationDetails: { color: '#888', fontSize: 12, marginTop: 4 },
  confirmedBadge: { marginTop: 8, alignSelf: 'flex-start', backgroundColor: '#4CAF50', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  confirmedText: { color: '#FFF', fontSize: 10, fontWeight: '600' },
  tablesGridManager: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  tableCardManager: { flex: 1, minWidth: '30%', backgroundColor: '#1A1A1A', padding: 16, borderRadius: 12, alignItems: 'center', borderWidth: 1, borderColor: '#2A2A2A' },
  tableBooked: { borderColor: '#FF4444', opacity: 0.7 },
  tableNumberManager: { color: '#D4AF37', fontSize: 18, fontWeight: '600', marginBottom: 4 },
  tableCapacityManager: { color: '#888', fontSize: 12, marginBottom: 8 },
  tableStatus: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  statusAvailable: { backgroundColor: '#4CAF50' },
  statusBooked: { backgroundColor: '#FF4444' },
  tableStatusText: { color: '#FFF', fontSize: 10, fontWeight: '600' },

  // Modals
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.8)', justifyContent: 'center', alignItems: 'center' },
  modalContainer: { backgroundColor: '#1A1A1A', borderRadius: 20, padding: 20, width: '85%' },
  modalTitle: { color: '#D4AF37', fontSize: 18, fontWeight: '600', marginBottom: 16, textAlign: 'center' },
  modalInput: { backgroundColor: '#2A2A2A', borderRadius: 10, padding: 12, color: '#FFF', marginBottom: 12 },
  modalButtons: { flexDirection: 'row', justifyContent: 'space-around', marginTop: 12 },
  modalCancel: { color: '#888', fontSize: 14 },
  modalSave: { color: '#D4AF37', fontSize: 14, fontWeight: '600' },

  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyEmoji: { fontSize: 60, marginBottom: 16, opacity: 0.5 },
  emptyText: { color: '#888', fontSize: 16 },
});

export default App;